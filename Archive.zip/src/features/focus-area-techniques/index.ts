export { TechniqueCard } from './TechniqueCard';
